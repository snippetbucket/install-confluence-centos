/***

    Author: Tejas Tank
    Powered By: SnippetBucket Technoliges, Offshore Office.
    Email: info@snippetbucket.com

*/

module.exports = {
    config: function(){
        return {
            'host': '192.168.1.119',
            'user': 'test1',
            'password': 'sb@123',
          };
    }
}
